<?php
// src/Scheduler/Message/CleanOldNotificationsMessage.php
namespace App\Scheduler\Message;

/**
 * Message déclenché chaque nuit pour supprimer
 * les notifications lues de plus de 30 jours
 */
class CleanOldNotificationsMessage
{
}
