<?php
// src/Scheduler/Message/DailyReportMessage.php
namespace App\Scheduler\Message;

/**
 * Message déclenché chaque matin à 8h pour
 * envoyer le rapport quotidien aux administrateurs
 */
class DailyReportMessage
{
}
