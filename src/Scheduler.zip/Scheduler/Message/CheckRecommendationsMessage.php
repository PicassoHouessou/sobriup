<?php
// src/Scheduler/Message/CheckRecommendationsMessage.php
namespace App\Scheduler\Message;

/**
 * Message déclenché toutes les heures pour vérifier :
 * - Conditions météo (Open-Meteo API)
 * - Heure (nuit, heures creuses EDF)
 * - Pannes d'équipements
 * - Surconsommation anormale
 */
class CheckRecommendationsMessage
{
}
