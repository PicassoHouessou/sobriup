<?php
// src/Scheduler/Handler/CheckRecommendationsHandler.php
namespace App\Scheduler\Handler;

use App\Scheduler\Message\CheckRecommendationsMessage;
use App\Service\RecommendationService;
use Psr\Log\LoggerInterface;
use Symfony\Component\Messenger\Attribute\AsMessageHandler;

#[AsMessageHandler]
class CheckRecommendationsHandler
{
    public function __construct(
        private readonly RecommendationService $recommendationService,
        private readonly LoggerInterface $logger
    ) {
    }

    public function __invoke(CheckRecommendationsMessage $message): void
    {
        $this->logger->info('[Scheduler] Démarrage vérification recommandations');

        try {
            $recommendations = $this->recommendationService->generateRecommendations();

            $this->logger->info('[Scheduler] Vérification terminée', [
                'nb_recommandations' => count($recommendations),
                'titres' => array_column($recommendations, 'title'),
            ]);
        } catch (\Exception $e) {
            $this->logger->error('[Scheduler] Erreur vérification recommandations', [
                'error' => $e->getMessage(),
            ]);
            throw $e;
        }
    }
}
