<?php
// src/Scheduler/Handler/DailyReportHandler.php
namespace App\Scheduler\Handler;

use App\Entity\ModuleHistory;
use App\Entity\User;
use App\Repository\ModuleHistoryRepository;
use App\Scheduler\Message\DailyReportMessage;
use App\Service\NotificationService;
use Doctrine\ORM\EntityManagerInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\Messenger\Attribute\AsMessageHandler;

#[AsMessageHandler]
class DailyReportHandler
{
    public function __construct(
        private readonly EntityManagerInterface $em,
        private readonly NotificationService $notificationService,
        private readonly LoggerInterface $logger
    ) {
    }

    public function __invoke(DailyReportMessage $message): void
    {
        $this->logger->info('[Scheduler] Génération rapport quotidien');

        try {
            $report = $this->buildReport();

            // Envoyer uniquement aux admins avec email
            $admins = $this->em->getRepository(User::class)
                ->createQueryBuilder('u')
                ->where('u.roles LIKE :role')
                ->setParameter('role', '%ROLE_ADMIN%')
                ->getQuery()
                ->getResult();

            foreach ($admins as $admin) {
                $this->notificationService->sendToUser(
                    $admin,
                    '📊 Rapport quotidien Sobri\'Up',
                    $report['message'],
                    'system',
                    true // ← envoyer email
                );
            }

            $this->logger->info('[Scheduler] Rapport envoyé', [
                'destinataires' => count($admins),
                'conso_hier' => $report['energy_yesterday'],
            ]);
        } catch (\Exception $e) {
            $this->logger->error('[Scheduler] Erreur rapport quotidien', [
                'error' => $e->getMessage(),
            ]);
            throw $e;
        }
    }

    private function buildReport(): array
    {
        $yesterday = new \DateTimeImmutable('yesterday');
        $today = new \DateTimeImmutable('today');
        $weekBefore = $yesterday->modify('-7 days');

        $repo = $this->em->getRepository(ModuleHistory::class);

        $energyYesterday = $repo->sumEnergy($yesterday, $today);
        $energyWeekBefore = $repo->sumEnergy($weekBefore, $yesterday);
        $avgPerDay = $energyWeekBefore > 0 ? $energyWeekBefore / 7 : 0;

        $diffPercent = $avgPerDay > 0
            ? round((($energyYesterday - $avgPerDay) / $avgPerDay) * 100, 1)
            : 0;

        $trend = $diffPercent <= 0 ? '📉 Réduction' : '📈 Augmentation';
        $sign = $diffPercent > 0 ? '+' : '';

        $message = sprintf(
            "Bilan énergétique du %s :\n\n" .
            "• Consommation : %.0f kWh\n" .
            "• Moyenne 7 derniers jours : %.0f kWh/jour\n" .
            "• %s de %s%.1f%% vs la semaine dernière\n\n" .
            "Bonne journée, l'équipe Sobri'Up.",
            $yesterday->format('d/m/Y'),
            $energyYesterday,
            $avgPerDay,
            $trend,
            $sign,
            abs($diffPercent)
        );

        return [
            'message' => $message,
            'energy_yesterday' => $energyYesterday,
            'avg_per_day' => $avgPerDay,
            'diff_percent' => $diffPercent,
        ];
    }
}
