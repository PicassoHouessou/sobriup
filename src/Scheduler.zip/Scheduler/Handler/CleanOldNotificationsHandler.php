<?php
// src/Scheduler/Handler/CleanOldNotificationsHandler.php
namespace App\Scheduler\Handler;

use App\Scheduler\Message\CleanOldNotificationsMessage;
use App\Service\NotificationService;
use Psr\Log\LoggerInterface;
use Symfony\Component\Messenger\Attribute\AsMessageHandler;

#[AsMessageHandler]
class CleanOldNotificationsHandler
{
    public function __construct(
        private readonly NotificationService $notificationService,
        private readonly LoggerInterface $logger
    ) {
    }

    public function __invoke(CleanOldNotificationsMessage $message): void
    {
        $this->logger->info('[Scheduler] Démarrage nettoyage notifications');

        try {
            $deleted = $this->notificationService->cleanOldNotifications();

            $this->logger->info('[Scheduler] Nettoyage terminé', [
                'supprimées' => $deleted,
            ]);
        } catch (\Exception $e) {
            $this->logger->error('[Scheduler] Erreur nettoyage notifications', [
                'error' => $e->getMessage(),
            ]);
            throw $e;
        }
    }
}
