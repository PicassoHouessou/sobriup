<?php

namespace App\Scheduler;

use App\Scheduler\Message\CheckRecommendationsMessage;
use App\Scheduler\Message\CleanOldNotificationsMessage;
use App\Scheduler\Message\DailyReportMessage;
use Symfony\Component\Scheduler\Attribute\AsSchedule;
use Symfony\Component\Scheduler\RecurringMessage;
use Symfony\Component\Scheduler\Schedule;
use Symfony\Component\Scheduler\ScheduleProviderInterface;
use Symfony\Contracts\Cache\CacheInterface;

#[AsSchedule('default')]
class RecommendationSchedule implements ScheduleProviderInterface
{
    /**
     * Mémoization : évite la reconstruction inutile du schedule
     * (bonne pratique mentionnée dans la doc officielle)
     */
    private ?Schedule $schedule = null;

    public function __construct(
        private readonly CacheInterface $cache,
    ) {
    }

    public function getSchedule(): Schedule
    {
        // ✅ Mémoization du schedule (pattern officiel doc Symfony 7.4)
        return $this->schedule ??= (new Schedule())
            ->with(
            // 1️⃣ Vérification recommandations toutes les heures
            // #hourly = "# * * * *" = à une minute aléatoire chaque heure
            // Évite les pics de charge si plusieurs schedulers tournent
                RecurringMessage::cron(
                    '#hourly',
                    new CheckRecommendationsMessage()
                ),

                // 2️⃣ Nettoyage des anciennes notifications chaque nuit
                // #midnight = "# #(0-2) * * *" = entre 0h et 2h59
                RecurringMessage::cron(
                    '#midnight',
                    new CleanOldNotificationsMessage()
                ),

                // 3️⃣ Rapport quotidien à 8h du matin
                // 0 8 * * * = tous les jours à exactement 8h00
                RecurringMessage::cron(
                    '0 8 * * *',
                    new DailyReportMessage()
                ),
            )
            // ✅ Stateful : mémorise la dernière exécution
            // Si le worker redémarre, il reprend là où il s'était arrêté
            ->stateful($this->cache)
            // ✅ Traite seulement le dernier run manqué (pas tous)
            // Évite les exécutions en rafale après un redémarrage long
            ->processOnlyLastMissedRun(true);
    }
}
